# ResQ India — Static Site (GitHub Pages Edition)

This is a **serverless** version of the ResQ India surplus-food marketplace: same UI, same features
(browsing, custom boxes, FSSAI-gated seller registration, 50% discount floor, AI savings calculator,
gamification, dashboards, Neighborhood Rescue Clubs), but it runs **entirely in the browser** — no
Node server, no database — so it can be published for free on GitHub Pages.

## ⚠️ The one big tradeoff

There is no shared backend. All data (accounts, listings, orders, points) is stored in the visiting
browser's `localStorage`. That means:
- Every visitor sees their **own separate copy** of the marketplace — orders you place aren't visible to anyone else
- Clearing browser data / using a different browser / incognito mode = a fresh, empty demo
- This is genuinely fine for a **portfolio piece, pitch demo, or personal prototype** — but it is not
  a real multi-user product. For that, you need the full Node.js version (`server/` folder in the
  other zip I gave you) deployed somewhere with a real backend, e.g. Render, Railway, or Fly.io.

## Publish it on GitHub Pages (free, ~2 minutes)

**1. Create a GitHub repo and push this folder**
```bash
cd resq-india-static
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/resq-india-static.git
git push -u origin main
```

**2. Turn on Pages**
- On GitHub, open your repo → **Settings** → **Pages** (left sidebar)
- Under "Build and deployment" → Source: **Deploy from a branch**
- Branch: **main**, folder: **/ (root)** → **Save**

**3. Wait ~1 minute, then visit your live site**
GitHub will show the URL at the top of that same Pages settings page — it looks like:
```
https://YOUR_USERNAME.github.io/resq-india-static/
```

Any time you push new commits to `main`, the live site updates automatically within a minute or two.

## Local testing before you push

Don't just double-click `index.html` — password hashing uses the browser's SubtleCrypto API, which
requires a "secure context" (HTTPS, or `localhost`). Serve it locally instead:
```bash
cd resq-india-static
python3 -m http.server 8080
# then open http://localhost:8080
```
(Or use the VS Code "Live Server" extension, or `npx serve`.)

## What's real vs. simulated here

- **Real**: 50% discount floor enforcement, FSSAI format validation, AI savings/carbon calculation,
  discount pricing heuristic, gamification/badges, custom box logic, club unlock logic — all the actual
  business rules run as real code against real (browser-local) data.
- **Simulated / not production-grade**: password hashing (SHA-256 via SubtleCrypto — fine for a demo,
  not real auth security), FSSAI verification (format check only, not the real government database),
  no payments, no real multi-user sharing.

## File map

```
index.html          Page structure
css/style.css        All styling (unchanged from the full-stack version)
js/store.js           localStorage-backed datastore
js/cryptoUtils.js     Password hashing + UUID generation, browser-native
js/aiEngine.js        Smart pricing, savings/carbon calc, recipes, forecasting, badges
js/validators.js      FSSAI/GST/phone/email checks + 50% discount floor
js/seedData.js        First-visit demo data (4 sellers, 9 listings, 1 demo buyer)
js/backend.js         All the old Express route logic, now plain functions over Store
js/app.js             UI logic — nearly identical to the full-stack version
```

Demo login after first load: `demo@resq.in` / `password123` (or just click **Reset demo data** in the
banner at the top of the site any time you want a clean slate).
