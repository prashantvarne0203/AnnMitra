// js/seedData.js
// Populates localStorage with demo data on first visit so the site isn't
// empty. Runs once — checks a flag so it never overwrites real demo activity.

async function seedIfEmpty() {
  const state = Store.readAll();
  if (state.sellers && state.sellers.length > 0) return; // already seeded

  function hrsFromNow(h) { return new Date(Date.now() + h * 3600000).toISOString(); }

  const sellersData = [
    { businessName: "Anand Bakers", ownerName: "Ramesh Anand", email: "anand@bakers.in", phone: "9876543210", shopType: "bakery", city: "Bengaluru", fssaiLicense: "12345678901234" },
    { businessName: "Spice Route Restaurant", ownerName: "Priya Menon", email: "priya@spiceroute.in", phone: "9876543211", shopType: "restaurant", city: "Bengaluru", fssaiLicense: "12345678901235" },
    { businessName: "FreshMart Supermarket", ownerName: "Vikram Shah", email: "vikram@freshmart.in", phone: "9876543212", shopType: "supermarket", city: "Bengaluru", fssaiLicense: "12345678901236" },
    { businessName: "Ganesh Sweets", ownerName: "Lakshmi Iyer", email: "lakshmi@ganeshsweets.in", phone: "9876543213", shopType: "sweet_shop", city: "Bengaluru", fssaiLicense: "12345678901237" }
  ];

  const sellers = [];
  for (const s of sellersData) {
    const seller = {
      id: CryptoUtils.uuid(), role: "seller", ...s,
      passwordHash: await CryptoUtils.hashPassword("password123"),
      gstNumber: null, address: `${s.businessName} Street, ${s.city}`,
      verified: true, verificationStatus: "verified", subscriptionPlan: "free",
      featured: Math.random() > 0.5, rating: +(3.8 + Math.random()).toFixed(1),
      totalOrders: 0, totalFoodKgRescued: 0, totalMoneyRecoveredInr: 0, totalCo2SavedKg: 0,
      createdAt: new Date().toISOString()
    };
    Store.insert("sellers", seller);
    sellers.push(seller);
  }

  const listingsData = [
    { seller: 0, title: "Assorted Bread & Buns (1kg box)", category: "bakery", originalPrice: 180, discountPercent: 60, quantityTotal: 15, unit: "box", weightKgPerUnit: 1, pickupBy: hrsFromNow(4), bakedAt: hrsFromNow(-6), bakeryFreshHours: 4 },
    { seller: 0, title: "Cake Slices Mixed Box", category: "bakery", originalPrice: 250, discountPercent: 50, quantityTotal: 10, unit: "box", weightKgPerUnit: 0.6, pickupBy: hrsFromNow(2) },
    { seller: 1, title: "Chef Rescue Box ₹199 (Family, serves 4)", category: "meal", originalPrice: 800, discountPercent: 75, quantityTotal: 8, unit: "box", weightKgPerUnit: 2, pickupBy: hrsFromNow(1.5), isFamilyPack: true },
    { seller: 1, title: "Buffet Leftovers – Closing Time Deal", category: "buffet", originalPrice: 400, discountPercent: 65, quantityTotal: 6, unit: "box", weightKgPerUnit: 1.5, pickupBy: hrsFromNow(0.4) },
    { seller: 1, title: "Mystery Gourmet Box (Premium)", category: "meal", originalPrice: 600, discountPercent: 55, quantityTotal: 5, unit: "box", weightKgPerUnit: 1.2, pickupBy: hrsFromNow(5), isMysteryBox: true },
    { seller: 2, title: "Fresh Vegetables Surplus Crate", category: "vegetables", originalPrice: 300, discountPercent: 55, quantityTotal: 20, unit: "kg", weightKgPerUnit: 1, pickupBy: hrsFromNow(10) },
    { seller: 2, title: "Ripe Fruits Mixed Basket", category: "fruits", originalPrice: 250, discountPercent: 50, quantityTotal: 12, unit: "kg", weightKgPerUnit: 1, pickupBy: hrsFromNow(8) },
    { seller: 2, title: "Dairy Nearing Best-Before (Milk/Curd/Paneer)", category: "dairy", originalPrice: 200, discountPercent: 50, quantityTotal: 10, unit: "box", weightKgPerUnit: 1, pickupBy: hrsFromNow(12) },
    { seller: 3, title: "Post-Festival Sweets Hamper", category: "sweets", originalPrice: 350, discountPercent: 60, quantityTotal: 10, unit: "box", weightKgPerUnit: 1, pickupBy: hrsFromNow(20) }
  ];

  listingsData.forEach((l) => {
    const seller = sellers[l.seller];
    Store.insert("listings", {
      id: CryptoUtils.uuid(), sellerId: seller.id, sellerName: seller.businessName, shopType: seller.shopType,
      title: l.title, description: "", category: l.category, originalPrice: l.originalPrice,
      discountPercent: l.discountPercent, quantityTotal: l.quantityTotal, quantityRemaining: l.quantityTotal,
      unit: l.unit, weightKgPerUnit: l.weightKgPerUnit, pickupBy: l.pickupBy, city: seller.city,
      isFamilyPack: !!l.isFamilyPack, isMysteryBox: !!l.isMysteryBox, flashSale: false,
      bakedAt: l.bakedAt || null, bakeryFreshHours: l.bakeryFreshHours || 4, createdAt: new Date().toISOString()
    });
  });

  Store.insert("users", {
    id: CryptoUtils.uuid(), role: "buyer", name: "Demo User", email: "demo@resq.in", phone: "9123456780",
    passwordHash: await CryptoUtils.hashPassword("password123"),
    subscription: false, points: 0, totalFoodKg: 0, totalCo2Kg: 0, totalWaterL: 0, totalMoneySavedInr: 0,
    badges: [], createdAt: new Date().toISOString()
  });
}
