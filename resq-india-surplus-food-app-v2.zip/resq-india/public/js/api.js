const API = (() => {
  const base = '/api';
  function token() { return localStorage.getItem('resq_token'); }
  async function req(method, path, body) {
    const headers = { 'Content-Type': 'application/json' };
    const t = token();
    if (t) headers['Authorization'] = 'Bearer ' + t;
    const res = await fetch(base + path, {
      method, headers, body: body ? JSON.stringify(body) : undefined
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }
  return {
    signup: (b) => req('POST', '/auth/signup', b),
    login: (b) => req('POST', '/auth/login', b),
    listings: (qs = '') => req('GET', '/listings' + qs),
    suggestPrice: (b) => req('POST', '/listings/suggest-price', b),
    createListing: (b) => req('POST', '/listings', b),
    shops: (qs = '') => req('GET', '/shops' + qs),
    shopDetail: (id) => req('GET', '/shops/' + id),
    plans: () => req('GET', '/shops/plans/list'),
    subscribeShop: (id, plan) => req('POST', `/shops/${id}/subscribe`, { plan }),
    shopDashboard: (id) => req('GET', `/shops/${id}/dashboard`),
    placeOrder: (b) => req('POST', '/orders', b),
    myOrders: () => req('GET', '/orders/mine'),
    myImpact: () => req('GET', '/orders/impact/me'),
    clubs: () => req('GET', '/clubs'),
    createClub: (b) => req('POST', '/clubs', b),
    joinClub: (id) => req('POST', `/clubs/${id}/join`),
    leaderboard: () => req('GET', '/dashboard/leaderboard'),
    badges: () => req('GET', '/dashboard/badges'),
    membershipPlans: () => req('GET', '/dashboard/membership/plans'),
    subscribeMembership: (plan) => req('POST', '/dashboard/membership/subscribe', { plan }),
    forecast: (shopId) => req('GET', '/dashboard/forecast/' + shopId)
  };
})();
