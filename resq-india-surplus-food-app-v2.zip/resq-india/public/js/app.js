let STATE = {
  user: JSON.parse(localStorage.getItem('resq_user') || 'null'),
  shop: JSON.parse(localStorage.getItem('resq_shop') || 'null')
};

function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3200);
}

function currency(n) { return '₹' + Math.round(n).toLocaleString('en-IN'); }

/* ---------------- Tabs ---------------- */
document.getElementById('tabs').addEventListener('click', (e) => {
  const btn = e.target.closest('.tab');
  if (!btn) return;
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('panel-' + btn.dataset.tab).classList.add('active');
  loadPanel(btn.dataset.tab);
});

function loadPanel(tab) {
  if (tab === 'browse') loadListings();
  if (tab === 'clubs') loadClubs();
  if (tab === 'impact') loadImpact();
  if (tab === 'leaderboard') loadLeaderboard();
  if (tab === 'sell') loadSell();
}

/* ---------------- Auth ---------------- */
function renderAuthBox() {
  const box = document.getElementById('authBox');
  if (STATE.user) {
    box.innerHTML = `
      <div class="user-chip">👋 ${STATE.user.name} · <span class="pts">${STATE.user.points || 0} pts</span></div>
      <button class="btn ghost small" id="logoutBtn">Log out</button>`;
    document.getElementById('logoutBtn').onclick = () => {
      localStorage.removeItem('resq_token'); localStorage.removeItem('resq_user'); localStorage.removeItem('resq_shop');
      STATE = { user: null, shop: null };
      renderAuthBox(); toast('Logged out'); loadPanel(currentTab());
    };
  } else {
    box.innerHTML = `<button class="btn ghost" id="loginBtn">Log in</button><button class="btn solid" id="signupBtn">Join Free</button>`;
    document.getElementById('loginBtn').onclick = () => openAuthModal('login');
    document.getElementById('signupBtn').onclick = () => openAuthModal('signup');
  }
}
function currentTab() { return document.querySelector('.tab.active')?.dataset.tab || 'browse'; }

function openAuthModal(mode) {
  const modal = document.getElementById('modal');
  const isSignup = mode === 'signup';
  modal.innerHTML = `
    <span class="modal-close" id="modalClose">✕</span>
    <h3>${isSignup ? 'Join ResQ India' : 'Log in'}</h3>
    <div class="form-row"><label>Name</label><input id="afName" ${isSignup ? '' : 'style="display:none"'} placeholder="Full name"></div>
    <div class="form-row"><label>Email</label><input id="afEmail" type="email" placeholder="you@example.com"></div>
    <div class="form-row"><label>Password</label><input id="afPass" type="password" placeholder="••••••••"></div>
    ${isSignup ? `
    <div class="form-row"><label>I am a</label>
      <select id="afRole"><option value="consumer">Consumer — buy surplus</option><option value="seller">Seller — list surplus (needs FSSAI)</option></select>
    </div>
    <div class="form-row"><label><input type="checkbox" id="afStudent"> I'm a student / hostel resident</label></div>
    ` : ''}
    <button class="btn solid full" id="afSubmit">${isSignup ? 'Create account' : 'Log in'}</button>
    <p class="form-hint" style="margin-top:10px">Demo login: demo@resq.in / password123</p>
  `;
  document.getElementById('modalBackdrop').classList.add('active');
  document.getElementById('modalClose').onclick = closeModal;
  document.getElementById('afSubmit').onclick = async () => {
    const email = document.getElementById('afEmail').value.trim();
    const password = document.getElementById('afPass').value;
    try {
      let data;
      if (isSignup) {
        const name = document.getElementById('afName').value.trim();
        const role = document.getElementById('afRole').value;
        const studentMode = document.getElementById('afStudent').checked;
        data = await API.signup({ name, email, password, role, studentMode });
      } else {
        data = await API.login({ email, password });
      }
      localStorage.setItem('resq_token', data.token);
      localStorage.setItem('resq_user', JSON.stringify(data.user));
      if (data.shop) localStorage.setItem('resq_shop', JSON.stringify(data.shop));
      STATE.user = data.user; STATE.shop = data.shop || null;
      renderAuthBox(); closeModal(); toast(isSignup ? 'Welcome to ResQ India!' : 'Welcome back!');
      loadPanel(currentTab());
    } catch (err) { toast(err.message); }
  };
}
function closeModal() { document.getElementById('modalBackdrop').classList.remove('active'); }
document.getElementById('modalBackdrop').addEventListener('click', (e) => { if (e.target.id === 'modalBackdrop') closeModal(); });

/* ---------------- Ticker ---------------- */
async function loadTicker() {
  try {
    const { listings } = await API.listings('');
    const items = listings.slice(0, 10).map(l => `🔥 ${l.title} @ ${currency(l.currentPrice)} (was ${currency(l.originalPrice)}) — ${l.shopArea || l.shopName} `);
    const text = items.join(' &nbsp;•&nbsp; ') || 'No live deals right now — check back soon!';
    const track = document.getElementById('tickerTrack');
    track.innerHTML = text + ' &nbsp;•&nbsp; ' + text;
  } catch (e) { /* ignore */ }
}

/* ---------------- Browse / Bazaar ---------------- */
const DEAL_LABELS = {
  standard: 'Surplus Deal', mysteryBox: 'Mystery Box', chefBox: 'Chef Rescue Box', familyPack: 'Family Pack',
  flashSale: 'Flash Sale', auction: 'Live Auction', bakeryAutoDiscount: 'Bakery Deal', grocery: 'Grocery Rescue',
  tiffin: 'Tiffin Rescue', eventLeftover: 'Event Leftover', weddingRescue: 'Wedding Rescue', festivalRescue: 'Festival Deal',
  trainDeal: 'Train Pickup', officeLunch: 'Office Lunch', buffetDeal: 'Buffet Deal', studentDeal: 'Student Deal'
};

async function loadListings() {
  const grid = document.getElementById('listingsGrid');
  grid.innerHTML = '<p style="color:var(--muted)">Loading deals…</p>';
  const area = document.getElementById('areaFilter').value.trim();
  const dealType = document.getElementById('dealTypeFilter').value;
  const studentOnly = document.getElementById('studentOnly').checked;
  const params = new URLSearchParams();
  if (dealType) params.set('dealType', dealType);
  if (studentOnly) params.set('studentOnly', 'true');
  try {
    let { listings } = await API.listings('?' + params.toString());
    if (area) listings = listings.filter(l => (l.shopArea || '').toLowerCase().includes(area.toLowerCase()));
    if (!listings.length) { grid.innerHTML = '<p style="color:var(--muted)">No deals match right now.</p>'; return; }
    grid.innerHTML = listings.map(renderListingCard).join('');
    grid.querySelectorAll('[data-buy]').forEach(btn => btn.onclick = () => buyListing(btn.dataset.buy));
    grid.querySelectorAll('[data-club]').forEach(btn => btn.onclick = () => startClub(btn.dataset.club));
  } catch (e) { grid.innerHTML = `<p style="color:var(--muted)">${e.message}</p>`; }
}
document.getElementById('refreshListings').onclick = loadListings;
document.getElementById('dealTypeFilter').onchange = loadListings;
document.getElementById('studentOnly').onchange = loadListings;
document.getElementById('areaFilter').addEventListener('keyup', (e) => { if (e.key === 'Enter') loadListings(); });

function renderListingCard(l) {
  const expiresIn = Math.max(0, Math.round((new Date(l.expiresAt) - new Date()) / 60000));
  const timeLabel = expiresIn > 90 ? `${Math.round(expiresIn / 60)}h left` : `${expiresIn}m left`;
  return `
  <div class="card">
    <span class="card-badge">${DEAL_LABELS[l.dealType] || 'Deal'}</span>
    <h3>${l.title}</h3>
    <div class="shop-line">${l.shopName || ''} · ${l.shopArea || ''}</div>
    <div class="price-row">
      <span class="price-now">${currency(l.currentPrice)}</span>
      <span class="price-orig">${currency(l.originalPrice)}</span>
      <span class="discount-pill">${l.discountPercent}% off</span>
    </div>
    <div class="meta-line"><span>${timeLabel}</span><span>${l.unitsAvailable} left</span></div>
    <div class="card-actions">
      <button class="btn solid small" data-buy="${l.id}">Rescue it</button>
      <button class="btn ghost small" data-club="${l.id}" style="border-color:#00000022;color:#5c5346">Start club</button>
    </div>
  </div>`;
}

async function buyListing(listingId) {
  if (!STATE.user) return openAuthModal('login');
  try {
    const { order, impact, moneySaved, recipes, pointsEarned, newBadges } = await API.placeOrder({ listingId, qty: 1, fulfillment: 'pickup' });
    STATE.user.points = (STATE.user.points || 0) + pointsEarned;
    localStorage.setItem('resq_user', JSON.stringify(STATE.user));
    renderAuthBox();
    const reveal = order.revealedContents ? `\nRevealed: ${order.revealedContents}` : '';
    toast(`Rescued! Paid ${currency(order.pricePaid)} · Saved ${impact.qtyKg}kg food & ${impact.co2Kg}kg CO₂ · +${pointsEarned} pts${reveal}`);
    loadListings();
  } catch (e) { toast(e.message); }
}

async function startClub(listingId) {
  if (!STATE.user) return openAuthModal('login');
  try {
    const { club } = await API.createClub({ listingId, targetCount: 5, bulkDiscountPercent: 65 });
    toast('Rescue Club started! Share it — need ' + (club.targetCount - club.commits.length) + ' more neighbours to unlock 65% off.');
    loadPanel('clubs');
  } catch (e) { toast(e.message); }
}

/* ---------------- Clubs ---------------- */
async function loadClubs() {
  const grid = document.getElementById('clubsGrid');
  grid.innerHTML = '<p style="color:var(--muted)">Loading clubs…</p>';
  try {
    const { clubs } = await API.clubs();
    if (!clubs.length) { grid.innerHTML = '<p style="color:var(--muted)">No active clubs yet — start one from any deal in the Bazaar.</p>'; return; }
    grid.innerHTML = clubs.map(c => `
      <div class="card">
        <span class="card-badge">${c.unlocked ? 'UNLOCKED 🎉' : 'Forming'}</span>
        <h3>${c.commits.length}/${c.targetCount} neighbours joined</h3>
        <div class="shop-line">Unlocks ${c.bulkDiscountPercent}% off when full</div>
        <div class="meta-line"><span>Deadline: ${new Date(c.deadline).toLocaleTimeString()}</span></div>
        <div class="card-actions"><button class="btn solid small" data-join="${c.id}">Join club</button></div>
      </div>`).join('');
    grid.querySelectorAll('[data-join]').forEach(btn => btn.onclick = async () => {
      if (!STATE.user) return openAuthModal('login');
      try { await API.joinClub(btn.dataset.join); toast('Joined the club!'); loadClubs(); } catch (e) { toast(e.message); }
    });
  } catch (e) { grid.innerHTML = `<p>${e.message}</p>`; }
}

/* ---------------- Impact ---------------- */
async function loadImpact() {
  const cards = document.getElementById('impactCards');
  const badgesRow = document.getElementById('badgesRow');
  const ordersList = document.getElementById('ordersList');
  if (!STATE.user) { cards.innerHTML = '<p style="color:var(--muted)">Log in to see your impact.</p>'; badgesRow.innerHTML=''; ordersList.innerHTML=''; return; }
  try {
    const { stats, points, badges } = await API.myImpact();
    cards.innerHTML = `
      <div class="stat-card"><div class="num">${stats.kgSaved}kg</div><div class="label">Food rescued</div></div>
      <div class="stat-card"><div class="num">${stats.co2Saved}kg</div><div class="label">CO₂ avoided</div></div>
      <div class="stat-card"><div class="num">${stats.waterSaved}L</div><div class="label">Water saved</div></div>
      <div class="stat-card"><div class="num">${currency(stats.moneySaved)}</div><div class="label">Money saved</div></div>
      <div class="stat-card"><div class="num">${points}</div><div class="label">Points</div></div>
    `;
    badgesRow.innerHTML = badges.length ? badges.map(b => `<span class="badge-chip">🏅 ${b.replace(/_/g,' ')}</span>`).join('') : '<span style="color:var(--muted);font-size:13px">No badges yet — place your first order!</span>';
    const { orders } = await API.myOrders();
    ordersList.innerHTML = orders.length ? orders.map(o => `
      <div class="order-row">
        <span>${DEAL_LABELS[o.dealType] || 'Order'} · ${currency(o.pricePaid)}</span>
        <span class="tag">${o.savings.qtyKg}kg saved · ${o.savings.co2Kg}kg CO₂</span>
      </div>`).join('') : '<p style="color:var(--muted)">No orders yet.</p>';
  } catch (e) { cards.innerHTML = `<p>${e.message}</p>`; }
}

/* ---------------- Leaderboard ---------------- */
async function loadLeaderboard() {
  const el = document.getElementById('leaderboardList');
  el.innerHTML = 'Loading…';
  try {
    const { leaderboard } = await API.leaderboard();
    el.innerHTML = leaderboard.map((u, i) => `
      <div class="lb-row">
        <span class="lb-rank">#${i + 1}</span>
        <span class="lb-name">${u.name}</span>
        <span style="color:var(--muted);font-size:12px">${u.kgSaved}kg saved</span>
        <span class="lb-pts">${u.points} pts</span>
      </div>`).join('') || '<p style="color:var(--muted)">No data yet.</p>';
  } catch (e) { el.innerHTML = e.message; }
}

/* ---------------- Sell ---------------- */
async function loadSell() {
  const area = document.getElementById('sellArea');
  if (!STATE.user) {
    area.innerHTML = `<div class="form-card"><h3>Log in or sign up as a seller</h3><p class="form-hint">You'll need a valid 14-digit Indian FSSAI license number.</p>
    <button class="btn solid full" id="sellSignupBtn">Sign up as Seller</button></div>`;
    document.getElementById('sellSignupBtn').onclick = () => openSellerSignup();
    return;
  }
  if (STATE.user.role !== 'seller' || !STATE.shop) {
    area.innerHTML = `<div class="form-card"><h3>Register your shop</h3><p class="form-hint">FSSAI license required (14 digits).</p>
    <button class="btn solid full" id="sellSignupBtn">Register as Seller</button></div>`;
    document.getElementById('sellSignupBtn').onclick = () => openSellerSignup();
    return;
  }
  area.innerHTML = `
    <div class="shop-panel">
      <div class="form-card">
        <h3>${STATE.shop.name} <span style="font-size:12px;color:#8a8071">(${STATE.shop.type})</span></h3>
        <p class="form-hint">Plan: ${STATE.shop.subscriptionTier} ${STATE.shop.isFeatured ? '· Featured ⭐' : ''}</p>
        <div class="two-col">
          <button class="btn ghost full" id="upgradeGrowth">Upgrade to Growth (₹999/mo)</button>
          <button class="btn ghost full" id="upgradeChain">Upgrade to Chain (₹4999/mo)</button>
        </div>
      </div>
      <div class="form-card">
        <h3>AI Smart Pricing helper</h3>
        <div class="two-col">
          <div class="form-row"><label>Hours to closing</label><input id="aiHours" type="number" value="2"></div>
          <div class="form-row"><label>Category</label><select id="aiCategory"><option value="meal">Meal</option><option value="bakery">Bakery</option><option value="grocery">Grocery</option></select></div>
        </div>
        <button class="btn ghost full" id="aiSuggestBtn">Suggest discount</button>
        <p id="aiSuggestResult" class="form-hint" style="margin-top:8px"></p>
      </div>
      <div class="form-card">
        <h3>Create a listing</h3>
        <div class="form-row"><label>Title</label><input id="lTitle" placeholder="e.g. Butter Chicken Family Box"></div>
        <div class="two-col">
          <div class="form-row"><label>Category</label>
            <select id="lCategory"><option value="meal">Meal</option><option value="bakery">Bakery</option><option value="grocery">Grocery</option><option value="sweets">Sweets</option></select>
          </div>
          <div class="form-row"><label>Deal type</label>
            <select id="lDealType">
              <option value="standard">Standard surplus</option>
              <option value="chefBox">Chef Rescue Box (₹99/199/299)</option>
              <option value="mysteryBox">Mystery Gourmet Box</option>
              <option value="familyPack">Family Pack (4-6 people)</option>
              <option value="flashSale">Neighborhood Flash Sale</option>
              <option value="auction">Live Auction (price drops)</option>
              <option value="bakeryAutoDiscount">Bakery Auto-discount</option>
              <option value="grocery">Grocery Rescue</option>
              <option value="tiffin">Tiffin Rescue</option>
              <option value="eventLeftover">Event Leftover</option>
              <option value="weddingRescue">Wedding/Event Rescue</option>
              <option value="festivalRescue">Festival Rescue</option>
              <option value="trainDeal">Train Passenger Pickup</option>
              <option value="officeLunch">Office Lunch Bulk</option>
              <option value="buffetDeal">Last-minute Buffet</option>
              <option value="studentDeal">Student-only Deal</option>
            </select>
          </div>
        </div>
        <div class="two-col">
          <div class="form-row"><label>Original price (₹)</label><input id="lOrigPrice" type="number" value="300"></div>
          <div class="form-row"><label>Discount %</label><input id="lDiscount" type="number" value="50"></div>
        </div>
        <div class="two-col">
          <div class="form-row"><label>Weight per unit (kg)</label><input id="lQtyKg" type="number" step="0.1" value="0.5"></div>
          <div class="form-row"><label>Units available</label><input id="lUnits" type="number" value="5"></div>
        </div>
        <div class="form-row"><label>Available for (hours)</label><input id="lHours" type="number" value="3"></div>
        <div class="form-row"><label><input type="checkbox" id="lReveal"> Reveal contents only after purchase</label></div>
        <button class="btn solid full" id="lSubmit">Publish listing</button>
        <p class="form-hint" style="margin-top:8px">Platform enforces a minimum 50% discount on every listing.</p>
      </div>
    </div>
  `;
  document.getElementById('upgradeGrowth').onclick = () => upgradeShop('growth');
  document.getElementById('upgradeChain').onclick = () => upgradeShop('chain');
  document.getElementById('aiSuggestBtn').onclick = async () => {
    try {
      const hoursToClose = +document.getElementById('aiHours').value;
      const category = document.getElementById('aiCategory').value;
      const s = await API.suggestPrice({ hoursToClose, category });
      document.getElementById('aiSuggestResult').innerHTML = `Suggested: <b>${s.discount}% off</b><br>${s.reasons.join('<br>')}`;
      document.getElementById('lDiscount').value = s.discount;
    } catch (e) { toast(e.message); }
  };
  document.getElementById('lSubmit').onclick = async () => {
    try {
      const body = {
        title: document.getElementById('lTitle').value,
        category: document.getElementById('lCategory').value,
        dealType: document.getElementById('lDealType').value,
        originalPrice: +document.getElementById('lOrigPrice').value,
        discountPercent: +document.getElementById('lDiscount').value,
        qtyKg: +document.getElementById('lQtyKg').value,
        unitsAvailable: +document.getElementById('lUnits').value,
        expiresAt: new Date(Date.now() + (+document.getElementById('lHours').value) * 3600000).toISOString(),
        revealAfterPurchase: document.getElementById('lReveal').checked
      };
      await API.createListing(body);
      toast('Listing published!');
      document.getElementById('lTitle').value = '';
    } catch (e) { toast(e.message); }
  };
}

async function upgradeShop(plan) {
  try {
    const { shop } = await API.subscribeShop(STATE.shop.id, plan);
    STATE.shop = shop; localStorage.setItem('resq_shop', JSON.stringify(shop));
    toast(`Upgraded to ${plan}!`); loadSell();
  } catch (e) { toast(e.message); }
}

function openSellerSignup() {
  const modal = document.getElementById('modal');
  modal.innerHTML = `
    <span class="modal-close" id="modalClose">✕</span>
    <h3>Seller Registration</h3>
    <div class="form-row"><label>Your name</label><input id="sfName"></div>
    <div class="form-row"><label>Email</label><input id="sfEmail" type="email"></div>
    <div class="form-row"><label>Password</label><input id="sfPass" type="password"></div>
    <div class="form-row"><label>Shop name</label><input id="sfShopName"></div>
    <div class="form-row"><label>Shop type</label>
      <select id="sfShopType"><option value="restaurant">Restaurant</option><option value="bakery">Bakery</option><option value="supermarket">Supermarket</option><option value="sweetshop">Sweet Shop</option><option value="tiffin">Tiffin Service</option><option value="events">Wedding/Event Hall</option><option value="farmer">Farmer</option></select>
    </div>
    <div class="two-col">
      <div class="form-row"><label>City</label><input id="sfCity" value="Bengaluru"></div>
      <div class="form-row"><label>Area</label><input id="sfArea" placeholder="e.g. Koramangala"></div>
    </div>
    <div class="form-row"><label>FSSAI License (14 digits)</label><input id="sfFssai" placeholder="12345678900001"></div>
    <button class="btn solid full" id="sfSubmit">Register</button>
  `;
  document.getElementById('modalBackdrop').classList.add('active');
  document.getElementById('modalClose').onclick = closeModal;
  document.getElementById('sfSubmit').onclick = async () => {
    try {
      const data = await API.signup({
        name: document.getElementById('sfName').value,
        email: document.getElementById('sfEmail').value,
        password: document.getElementById('sfPass').value,
        role: 'seller',
        shopName: document.getElementById('sfShopName').value,
        shopType: document.getElementById('sfShopType').value,
        city: document.getElementById('sfCity').value,
        area: document.getElementById('sfArea').value,
        fssaiLicense: document.getElementById('sfFssai').value
      });
      localStorage.setItem('resq_token', data.token);
      localStorage.setItem('resq_user', JSON.stringify(data.user));
      localStorage.setItem('resq_shop', JSON.stringify(data.shop));
      STATE.user = data.user; STATE.shop = data.shop;
      renderAuthBox(); closeModal(); toast('Shop registered!'); loadSell();
    } catch (e) { toast(e.message); }
  };
}

/* ---------------- Init ---------------- */
renderAuthBox();
loadTicker();
loadListings();
setInterval(loadTicker, 20000);
