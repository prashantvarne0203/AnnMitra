const express = require('express');
const cors = require('cors');
const path = require('path');

const { router: authRouter } = require('./routes/auth');
const { router: shopsRouter } = require('./routes/shops');
const { router: listingsRouter } = require('./routes/listings');
const { router: ordersRouter } = require('./routes/orders');
const { router: clubsRouter } = require('./routes/clubs');
const { router: dashboardRouter } = require('./routes/dashboard');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use('/api/auth', authRouter);
app.use('/api/shops', shopsRouter);
app.use('/api/listings', listingsRouter);
app.use('/api/orders', ordersRouter);
app.use('/api/clubs', clubsRouter);
app.use('/api/dashboard', dashboardRouter);

app.get('/api/health', (req, res) => res.json({ ok: true, service: 'resq-india', time: new Date().toISOString() }));

app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Not found' });
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`ResQ India server running on http://localhost:${PORT}`);
});
