const express = require('express');
const { nanoid } = require('nanoid');
const { load, save } = require('../lib/store');
const { authMiddleware } = require('./auth');

const router = express.Router();

router.get('/', (req, res) => {
  const db = load();
  res.json({ clubs: db.clubs });
});

// Create a club around a listing — unlocks bulk discount once enough people commit
router.post('/', authMiddleware, (req, res) => {
  const db = load();
  const { listingId, targetCount = 5, bulkDiscountPercent = 60, deadlineMinutes = 120 } = req.body;
  const listing = db.listings.find(l => l.id === listingId);
  if (!listing) return res.status(404).json({ error: 'Listing not found' });

  const club = {
    id: nanoid(10),
    shopId: listing.shopId,
    listingId,
    targetCount,
    bulkDiscountPercent,
    commits: [req.user.id],
    unlocked: false,
    deadline: new Date(Date.now() + deadlineMinutes * 60000).toISOString(),
    createdAt: new Date().toISOString()
  };
  if (club.commits.length >= targetCount) club.unlocked = true;
  db.clubs.push(club);

  const user = db.users.find(u => u.id === req.user.id);
  user.stats.clubsJoined = (user.stats.clubsJoined || 0) + 1;

  save(db);
  res.json({ club });
});

router.post('/:id/join', authMiddleware, (req, res) => {
  const db = load();
  const club = db.clubs.find(c => c.id === req.params.id);
  if (!club) return res.status(404).json({ error: 'Club not found' });
  if (new Date(club.deadline).getTime() < Date.now()) return res.status(400).json({ error: 'Club deadline passed' });

  if (!club.commits.includes(req.user.id)) {
    club.commits.push(req.user.id);
    const user = db.users.find(u => u.id === req.user.id);
    user.stats.clubsJoined = (user.stats.clubsJoined || 0) + 1;
    user.badges = require('../lib/gamify').evaluateBadges(user);
  }
  if (club.commits.length >= club.targetCount) {
    club.unlocked = true;
    // Apply bulk discount to the underlying listing once unlocked
    const listing = db.listings.find(l => l.id === club.listingId);
    if (listing && club.bulkDiscountPercent > listing.discountPercent) {
      listing.discountPercent = club.bulkDiscountPercent;
      listing.discountedPrice = Math.round(listing.originalPrice * (1 - club.bulkDiscountPercent / 100));
    }
  }
  save(db);
  res.json({ club });
});

module.exports = { router };
