const express = require('express');
const { nanoid } = require('nanoid');
const { load, save } = require('../lib/store');
const { authMiddleware } = require('./auth');
const engine = require('../lib/engine');
const gamify = require('../lib/gamify');

const router = express.Router();

const COMMISSION_PERCENT = 15; // platform revenue: 10-20% commission, using 15% as default
const DELIVERY_FEE = 39;

router.post('/', authMiddleware, (req, res) => {
  const db = load();
  const { listingId, qty = 1, fulfillment = 'pickup', donateInstead = false, donationOrgType } = req.body;

  const listing = db.listings.find(l => l.id === listingId && l.active);
  if (!listing) return res.status(404).json({ error: 'Listing not found or no longer active' });
  if (new Date(listing.expiresAt).getTime() < Date.now()) return res.status(400).json({ error: 'Listing has expired' });
  if (listing.unitsAvailable < qty) return res.status(400).json({ error: 'Not enough units available' });

  let pricePerUnit = listing.discountedPrice;
  if (listing.dealType === 'auction' && listing.auction) {
    pricePerUnit = engine.auctionPrice({ ...listing.auction, startedAt: listing.createdAt });
  }

  const subtotal = pricePerUnit * qty;
  const deliveryFee = fulfillment === 'delivery' ? DELIVERY_FEE : 0;
  const commission = +(subtotal * (COMMISSION_PERCENT / 100)).toFixed(2);
  const pricePaid = subtotal + deliveryFee;

  const impact = engine.calcImpact({ qtyKg: listing.qtyKg * qty });
  const moneySaved = (listing.originalPrice - pricePerUnit) * qty;

  const order = {
    id: nanoid(10),
    userId: req.user.id,
    shopId: listing.shopId,
    listingId: listing.id,
    dealType: listing.dealType,
    qty,
    pricePerUnit,
    pricePaid,
    deliveryFee,
    commission,
    fulfillment,
    donateInstead: !!donateInstead,
    savings: { ...impact, moneySaved },
    revealedContents: listing.revealAfterPurchase ? (listing.contents || 'Chef\'s surprise selection — enjoy!') : null,
    status: 'confirmed',
    placedAt: new Date().toISOString()
  };

  listing.unitsAvailable -= qty;
  if (listing.unitsAvailable <= 0) listing.active = false;

  db.orders.push(order);

  // Update user stats, points, badges
  const user = db.users.find(u => u.id === req.user.id);
  user.stats.ordersCount += 1;
  user.stats.kgSaved = +(user.stats.kgSaved + impact.qtyKg).toFixed(2);
  user.stats.co2Saved = +(user.stats.co2Saved + impact.co2Kg).toFixed(2);
  user.stats.waterSaved += impact.waterL;
  user.stats.moneySaved += moneySaved;
  user.points += gamify.pointsForOrder({ qtyKg: impact.qtyKg, moneySaved });
  user.badges = gamify.evaluateBadges(user);

  if (donateInstead) {
    db.donations.push({
      id: nanoid(10), userId: user.id, orderId: order.id,
      orgType: donationOrgType || 'ngo', mealsSponsored: qty,
      createdAt: new Date().toISOString()
    });
  }

  save(db);

  // Recipe suggestions bundled into the receipt
  const recipes = engine.suggestRecipes(listing.category);

  res.json({ order, impact, moneySaved, recipes, pointsEarned: gamify.pointsForOrder({ qtyKg: impact.qtyKg, moneySaved }), newBadges: user.badges });
});

router.get('/mine', authMiddleware, (req, res) => {
  const db = load();
  const orders = db.orders.filter(o => o.userId === req.user.id).sort((a, b) => new Date(b.placedAt) - new Date(a.placedAt));
  res.json({ orders });
});

// Consumer carbon/savings dashboard
router.get('/impact/me', authMiddleware, (req, res) => {
  const db = load();
  const user = db.users.find(u => u.id === req.user.id);
  res.json({ stats: user.stats, points: user.points, badges: user.badges });
});

module.exports = { router, COMMISSION_PERCENT, DELIVERY_FEE };
