const express = require('express');
const { nanoid } = require('nanoid');
const { load, save } = require('../lib/store');
const { authMiddleware } = require('./auth');
const engine = require('../lib/engine');

const router = express.Router();

const MIN_DISCOUNT_PERCENT = 50; // hard platform floor — enforced server-side, not just UI

// Deal types recognised by the platform (drives frontend badges/behaviour)
const DEAL_TYPES = [
  'standard', 'mysteryBox', 'chefBox', 'familyPack', 'flashSale', 'auction',
  'bakeryAutoDiscount', 'grocery', 'tiffin', 'eventLeftover', 'weddingRescue',
  'festivalRescue', 'trainDeal', 'officeLunch', 'buffetDeal', 'studentDeal'
];

function computeDiscountedPrice(originalPrice, discountPercent) {
  return Math.round(originalPrice * (1 - discountPercent / 100));
}

router.get('/deal-types', (req, res) => res.json({ dealTypes: DEAL_TYPES }));

// Browse/search listings with filters (near-me, category, dealType, student mode, happy-hour map)
router.get('/', (req, res) => {
  const db = load();
  const { category, dealType, city, lat, lng, maxMinutes, studentOnly } = req.query;
  const now = Date.now();

  let listings = db.listings.filter(l => l.active && new Date(l.expiresAt).getTime() > now);

  if (category) listings = listings.filter(l => l.category === category);
  if (dealType) listings = listings.filter(l => l.dealType === dealType);
  if (studentOnly === 'true') listings = listings.filter(l => l.studentDeal);

  listings = listings.map(l => {
    const shop = db.shops.find(s => s.id === l.shopId);
    let currentPrice = l.discountedPrice;
    if (l.dealType === 'auction' && l.auction) {
      currentPrice = engine.auctionPrice({ ...l.auction, startedAt: l.createdAt, now });
    }
    let distanceKm = null, minutesAway = null;
    if (lat && lng && shop?.lat && shop?.lng) {
      distanceKm = +engine.haversineKm(+lat, +lng, shop.lat, shop.lng).toFixed(1);
      minutesAway = Math.round(engine.withinMinutes(distanceKm));
    }
    return {
      ...l,
      currentPrice,
      shopName: shop?.name,
      shopType: shop?.type,
      shopArea: shop?.area,
      shopCity: shop?.city,
      distanceKm, minutesAway,
      // Mystery/chef boxes hide contents until purchase
      title: l.revealAfterPurchase ? maskTitle(l) : l.title,
      contents: l.revealAfterPurchase ? undefined : l.contents
    };
  });

  if (city) listings = listings.filter(l => l.shopCity?.toLowerCase() === city.toLowerCase());
  if (maxMinutes && lat && lng) listings = listings.filter(l => l.minutesAway === null || l.minutesAway <= +maxMinutes);

  res.json({ listings });
});

function maskTitle(l) {
  if (l.dealType === 'mysteryBox') return `Mystery Gourmet Box — ${l.shopCategory || l.category}`;
  if (l.dealType === 'chefBox') return `Chef Rescue Box — ₹${l.discountedPrice}`;
  return l.title;
}

// AI smart-pricing suggestion (sellers call this before publishing)
router.post('/suggest-price', authMiddleware, (req, res) => {
  const { hoursToClose, category, weather, demandLevel } = req.body;
  const suggestion = engine.suggestDiscount({ hoursToClose, category, weather, demandLevel });
  res.json(suggestion);
});

// Create a listing
router.post('/', authMiddleware, (req, res) => {
  const db = load();
  const shop = db.shops.find(s => s.ownerId === req.user.id);
  if (!shop) return res.status(403).json({ error: 'Only registered sellers with a verified shop can create listings' });
  if (!shop.verified) return res.status(403).json({ error: 'Shop FSSAI license not verified yet' });

  const {
    title, category, originalPrice, discountPercent, qtyKg, expiresAt,
    dealType = 'standard', contents, fixedPrice, auction, minPeopleForFamilyPack,
    studentDeal, revealAfterPurchase
  } = req.body;

  if (!title || !originalPrice || !qtyKg || !expiresAt) {
    return res.status(400).json({ error: 'title, originalPrice, qtyKg, expiresAt are required' });
  }

  let finalDiscountPercent = discountPercent || MIN_DISCOUNT_PERCENT;
  if (finalDiscountPercent < MIN_DISCOUNT_PERCENT) {
    return res.status(400).json({ error: `Minimum discount on this platform is ${MIN_DISCOUNT_PERCENT}%. Adjust your price.` });
  }

  let discountedPrice = computeDiscountedPrice(originalPrice, finalDiscountPercent);

  // Chef Rescue Box: force fixed India-friendly price points regardless of computed discount,
  // as long as that price still clears the 50% floor.
  if (dealType === 'chefBox') {
    const allowed = [99, 199, 299];
    const chosen = fixedPrice && allowed.includes(+fixedPrice) ? +fixedPrice : 99;
    if (chosen > originalPrice * (1 - MIN_DISCOUNT_PERCENT / 100)) {
      return res.status(400).json({ error: `Fixed price ₹${chosen} does not meet the 50% minimum discount vs original price ₹${originalPrice}` });
    }
    discountedPrice = chosen;
    finalDiscountPercent = Math.round((1 - discountedPrice / originalPrice) * 100);
  }

  const listing = {
    id: nanoid(10),
    shopId: shop.id,
    title,
    category: category || 'meal',
    dealType: DEAL_TYPES.includes(dealType) ? dealType : 'standard',
    originalPrice,
    discountPercent: finalDiscountPercent,
    discountedPrice,
    qtyKg: +qtyKg,
    unitsAvailable: req.body.unitsAvailable || 1,
    expiresAt,
    active: true,
    contents: contents || null, // e.g. list of items in a mystery/family box — hidden until purchase if flagged
    revealAfterPurchase: !!revealAfterPurchase || dealType === 'mysteryBox',
    minPeopleForFamilyPack: dealType === 'familyPack' ? (minPeopleForFamilyPack || 4) : null,
    studentDeal: !!studentDeal || dealType === 'studentDeal',
    auction: dealType === 'auction' ? {
      basePrice: auction?.basePrice || originalPrice,
      floorPrice: auction?.floorPrice || discountedPrice,
      dropIntervalMin: auction?.dropIntervalMin || 10,
      dropPercent: auction?.dropPercent || 10
    } : null,
    createdAt: new Date().toISOString()
  };

  db.listings.push(listing);
  save(db);
  res.json({ listing });
});

// Bakery auto-discount tick: called periodically (or on-demand) to age bakery items into deeper discount
router.post('/:id/bakery-tick', authMiddleware, (req, res) => {
  const db = load();
  const listing = db.listings.find(l => l.id === req.params.id);
  if (!listing) return res.status(404).json({ error: 'Not found' });
  if (listing.dealType !== 'bakeryAutoDiscount') return res.status(400).json({ error: 'Not a bakery auto-discount listing' });

  const hoursOld = (Date.now() - new Date(listing.createdAt).getTime()) / 3600000;
  const suggestion = engine.suggestDiscount({ hoursToClose: Math.max(0.5, 6 - hoursOld), category: 'bakery' });
  listing.discountPercent = Math.max(listing.discountPercent, suggestion.discount);
  listing.discountedPrice = computeDiscountedPrice(listing.originalPrice, listing.discountPercent);
  save(db);
  res.json({ listing, reasoning: suggestion.reasons });
});

module.exports = { router, DEAL_TYPES, MIN_DISCOUNT_PERCENT, computeDiscountedPrice };
