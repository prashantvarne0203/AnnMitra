const express = require('express');
const { load, save } = require('../lib/store');
const { authMiddleware } = require('./auth');

const router = express.Router();

const SUBSCRIPTION_PLANS = {
  free: { label: 'Free', monthlyFee: 0, featuredSlots: 0 },
  growth: { label: 'Growth', monthlyFee: 999, featuredSlots: 1 },
  chain: { label: 'Chain / Enterprise', monthlyFee: 4999, featuredSlots: 5, analytics: true }
};

router.get('/', (req, res) => {
  const db = load();
  const { city, type, area } = req.query;
  let shops = db.shops.filter(s => s.verified);
  if (city) shops = shops.filter(s => s.city?.toLowerCase() === city.toLowerCase());
  if (type) shops = shops.filter(s => s.type === type);
  if (area) shops = shops.filter(s => s.area?.toLowerCase().includes(area.toLowerCase()));
  // Featured shops first (revenue model: featured listings)
  shops = shops.sort((a, b) => (b.isFeatured === true) - (a.isFeatured === true));
  res.json({ shops });
});

router.get('/:id', (req, res) => {
  const db = load();
  const shop = db.shops.find(s => s.id === req.params.id);
  if (!shop) return res.status(404).json({ error: 'Shop not found' });
  const listings = db.listings.filter(l => l.shopId === shop.id && l.active);
  res.json({ shop, listings });
});

router.get('/plans/list', (req, res) => {
  res.json({ plans: SUBSCRIPTION_PLANS });
});

// Upgrade subscription (monthly subscription for businesses + featured listings revenue stream)
router.post('/:id/subscribe', authMiddleware, (req, res) => {
  const { plan } = req.body;
  if (!SUBSCRIPTION_PLANS[plan]) return res.status(400).json({ error: 'Unknown plan' });
  const db = load();
  const shop = db.shops.find(s => s.id === req.params.id);
  if (!shop) return res.status(404).json({ error: 'Shop not found' });
  if (shop.ownerId !== req.user.id) return res.status(403).json({ error: 'Not your shop' });

  shop.subscriptionTier = plan;
  shop.isFeatured = SUBSCRIPTION_PLANS[plan].featuredSlots > 0;
  db.subscriptions.push({
    shopId: shop.id, plan, monthlyFee: SUBSCRIPTION_PLANS[plan].monthlyFee, startedAt: new Date().toISOString()
  });
  save(db);
  res.json({ shop });
});

// Corporate / sustainability dashboard for large chains (revenue: sustainability analytics)
router.get('/:id/dashboard', authMiddleware, (req, res) => {
  const db = load();
  const shop = db.shops.find(s => s.id === req.params.id);
  if (!shop) return res.status(404).json({ error: 'Shop not found' });
  if (shop.ownerId !== req.user.id) return res.status(403).json({ error: 'Not your shop' });

  const listingIds = db.listings.filter(l => l.shopId === shop.id).map(l => l.id);
  const orders = db.orders.filter(o => listingIds.includes(o.listingId));

  const foodWasteReducedKg = +orders.reduce((s, o) => s + o.savings.qtyKg, 0).toFixed(2);
  const moneyRecovered = orders.reduce((s, o) => s + o.pricePaid, 0);
  const co2Savings = +orders.reduce((s, o) => s + o.savings.co2Kg, 0).toFixed(2);
  const productCounts = {};
  orders.forEach(o => {
    const l = db.listings.find(x => x.id === o.listingId);
    if (l) productCounts[l.title] = (productCounts[l.title] || 0) + o.qty;
  });
  const popularProducts = Object.entries(productCounts).sort((a, b) => b[1] - a[1]).slice(0, 5);

  const hourCounts = {};
  orders.forEach(o => {
    const h = new Date(o.placedAt).getHours();
    hourCounts[h] = (hourCounts[h] || 0) + 1;
  });
  const peakHours = Object.entries(hourCounts).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([h]) => `${h}:00`);

  res.json({
    shop: { name: shop.name, tier: shop.subscriptionTier },
    foodWasteReducedKg, moneyRecovered, co2Savings,
    popularProducts, peakHours,
    ordersCount: orders.length,
    analyticsIncluded: SUBSCRIPTION_PLANS[shop.subscriptionTier]?.analytics || false
  });
});

module.exports = { router, SUBSCRIPTION_PLANS };
