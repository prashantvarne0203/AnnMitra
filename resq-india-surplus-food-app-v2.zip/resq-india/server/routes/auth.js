const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { nanoid } = require('nanoid');
const { load, save } = require('../lib/store');

const JWT_SECRET = process.env.JWT_SECRET || 'resq-india-dev-secret';
const router = express.Router();

function isValidFssai(license) {
  // FSSAI license numbers are 14 digits
  return /^\d{14}$/.test(String(license || '').trim());
}

router.post('/signup', (req, res) => {
  const { name, email, password, role, studentMode, fssaiLicense, shopName, shopType, city, area } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'name, email, password required' });

  const db = load();
  if (db.users.find(u => u.email === email)) {
    return res.status(409).json({ error: 'Email already registered' });
  }

  const passwordHash = bcrypt.hashSync(password, 8);
  const user = {
    id: nanoid(10),
    name, email, passwordHash,
    role: role === 'seller' ? 'seller' : 'consumer',
    studentMode: !!studentMode,
    points: 0,
    badges: [],
    stats: { ordersCount: 0, kgSaved: 0, co2Saved: 0, waterSaved: 0, moneySaved: 0, clubsJoined: 0 },
    isPremiumMember: false,
    createdAt: new Date().toISOString()
  };
  db.users.push(user);

  let shop = null;
  if (role === 'seller') {
    if (!isValidFssai(fssaiLicense)) {
      return res.status(400).json({ error: 'A valid 14-digit Indian FSSAI license number is required to register as a seller.' });
    }
    shop = {
      id: nanoid(10),
      ownerId: user.id,
      name: shopName || `${name}'s Shop`,
      type: shopType || 'restaurant',
      fssaiLicense,
      verified: true, // format-verified; real DB check documented as future work
      isFeatured: false,
      subscriptionTier: 'free',
      city: city || 'Bengaluru',
      area: area || '',
      lat: null, lng: null,
      rating: 4.5,
      createdAt: new Date().toISOString()
    };
    db.shops.push(shop);
  }

  save(db);
  const token = jwt.sign({ uid: user.id }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: sanitizeUser(user), shop });
});

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  const db = load();
  const user = db.users.find(u => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  const token = jwt.sign({ uid: user.id }, JWT_SECRET, { expiresIn: '7d' });
  const shop = db.shops.find(s => s.ownerId === user.id) || null;
  res.json({ token, user: sanitizeUser(user), shop });
});

function sanitizeUser(u) {
  const { passwordHash, ...rest } = u;
  return rest;
}

function authMiddleware(req, res, next) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing auth token' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const db = load();
    const user = db.users.find(u => u.id === payload.uid);
    if (!user) return res.status(401).json({ error: 'Invalid token' });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

module.exports = { router, authMiddleware, isValidFssai, sanitizeUser, JWT_SECRET };
