const express = require('express');
const { load, save } = require('../lib/store');
const { authMiddleware } = require('./auth');
const engine = require('../lib/engine');
const gamify = require('../lib/gamify');

const router = express.Router();

router.get('/leaderboard', (req, res) => {
  const db = load();
  const top = [...db.users]
    .sort((a, b) => b.points - a.points)
    .slice(0, 20)
    .map(u => ({ name: u.name, points: u.points, badges: u.badges, kgSaved: u.stats.kgSaved }));
  res.json({ leaderboard: top });
});

router.get('/badges', (req, res) => res.json({ badges: gamify.BADGES.map(({ id, label }) => ({ id, label })) }));

// Premium consumer membership (revenue model)
const MEMBERSHIP_PLANS = {
  basic: { label: 'Free', monthlyFee: 0 },
  saver_plus: { label: 'Saver+', monthlyFee: 99, perks: ['Early access to flash sales', 'Free delivery on 2 orders/month'] }
};

router.get('/membership/plans', (req, res) => res.json({ plans: MEMBERSHIP_PLANS }));

router.post('/membership/subscribe', authMiddleware, (req, res) => {
  const { plan } = req.body;
  if (!MEMBERSHIP_PLANS[plan]) return res.status(400).json({ error: 'Unknown plan' });
  const db = load();
  const user = db.users.find(u => u.id === req.user.id);
  user.isPremiumMember = plan !== 'basic';
  user.membershipPlan = plan;
  db.memberships.push({ userId: user.id, plan, startedAt: new Date().toISOString() });
  save(db);
  res.json({ user: { ...user, passwordHash: undefined } });
});

// Demand forecasting for a shop (seller-facing)
router.get('/forecast/:shopId', authMiddleware, (req, res) => {
  const db = load();
  const shop = db.shops.find(s => s.id === req.params.shopId);
  if (!shop) return res.status(404).json({ error: 'Shop not found' });
  const listingIds = db.listings.filter(l => l.shopId === shop.id).map(l => l.id);
  const orders = db.orders.filter(o => listingIds.includes(o.listingId));
  const forecast = engine.forecastDemand(orders);
  res.json(forecast);
});

module.exports = { router, MEMBERSHIP_PLANS };
