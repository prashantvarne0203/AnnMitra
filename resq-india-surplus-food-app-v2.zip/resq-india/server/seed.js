const bcrypt = require('bcryptjs');
const { nanoid } = require('nanoid');
const { save } = require('./lib/store');

const now = Date.now();
const hrs = (h) => new Date(now + h * 3600000).toISOString();

const demoConsumer = {
  id: 'demo-user-1', name: 'Demo User', email: 'demo@resq.in',
  passwordHash: bcrypt.hashSync('password123', 8),
  role: 'consumer', studentMode: false, points: 0, badges: [],
  stats: { ordersCount: 0, kgSaved: 0, co2Saved: 0, waterSaved: 0, moneySaved: 0, clubsJoined: 0 },
  isPremiumMember: false, createdAt: new Date().toISOString()
};

const sellerUsers = [
  { id: 'seller-1', name: 'Spice Route Kitchen', shopType: 'restaurant', area: 'Indiranagar', city: 'Bengaluru' },
  { id: 'seller-2', name: 'Golden Crust Bakery', shopType: 'bakery', area: 'Koramangala', city: 'Bengaluru' },
  { id: 'seller-3', name: 'FreshMart Supermarket', shopType: 'supermarket', area: 'HSR Layout', city: 'Bengaluru' },
  { id: 'seller-4', name: 'Amma\'s Tiffin Service', shopType: 'tiffin', area: 'BTM Layout', city: 'Bengaluru' },
  { id: 'seller-5', name: 'Grand Palace Banquets', shopType: 'events', area: 'Whitefield', city: 'Bengaluru' }
];

const users = [demoConsumer];
const shops = [];

sellerUsers.forEach((s, i) => {
  users.push({
    id: s.id, name: s.name, email: `seller${i + 1}@resq.in`,
    passwordHash: bcrypt.hashSync('password123', 8),
    role: 'seller', studentMode: false, points: 0, badges: [],
    stats: { ordersCount: 0, kgSaved: 0, co2Saved: 0, waterSaved: 0, moneySaved: 0, clubsJoined: 0 },
    isPremiumMember: false, createdAt: new Date().toISOString()
  });
  shops.push({
    id: `shop-${i + 1}`, ownerId: s.id, name: s.name, type: s.shopType,
    fssaiLicense: `1234567800000${i}`.slice(0, 14), verified: true,
    isFeatured: i === 0, subscriptionTier: i === 0 ? 'chain' : 'free',
    city: s.city, area: s.area, lat: 12.97 + i * 0.01, lng: 77.59 + i * 0.01,
    rating: 4.2 + i * 0.1, createdAt: new Date().toISOString()
  });
});

const listings = [
  {
    id: 'listing-1', shopId: 'shop-1', title: 'Chef Rescue Box', category: 'meal', dealType: 'chefBox',
    originalPrice: 450, discountPercent: 78, discountedPrice: 99, qtyKg: 0.6, unitsAvailable: 15,
    expiresAt: hrs(4), active: true, contents: 'Chef\'s surprise 2-course meal', revealAfterPurchase: true,
    minPeopleForFamilyPack: null, studentDeal: false, auction: null, createdAt: new Date().toISOString()
  },
  {
    id: 'listing-2', shopId: 'shop-1', title: 'Mystery Gourmet Box', category: 'meal', dealType: 'mysteryBox',
    originalPrice: 899, discountPercent: 55, discountedPrice: 404, qtyKg: 1.2, unitsAvailable: 6,
    expiresAt: hrs(3), active: true, contents: 'Premium tasting selection, revealed on pickup', revealAfterPurchase: true,
    minPeopleForFamilyPack: null, studentDeal: false, auction: null, createdAt: new Date().toISOString()
  },
  {
    id: 'listing-3', shopId: 'shop-2', title: 'Assorted Bread & Pastry Box', category: 'bakery', dealType: 'bakeryAutoDiscount',
    originalPrice: 300, discountPercent: 50, discountedPrice: 150, qtyKg: 1.0, unitsAvailable: 10,
    expiresAt: hrs(2), active: true, contents: null, revealAfterPurchase: false,
    minPeopleForFamilyPack: null, studentDeal: false, auction: null, createdAt: new Date(now - 4 * 3600000).toISOString()
  },
  {
    id: 'listing-4', shopId: 'shop-3', title: 'Fruit & Veg Rescue Crate', category: 'grocery', dealType: 'grocery',
    originalPrice: 500, discountPercent: 60, discountedPrice: 200, qtyKg: 3.5, unitsAvailable: 8,
    expiresAt: hrs(20), active: true, contents: null, revealAfterPurchase: false,
    minPeopleForFamilyPack: null, studentDeal: false, auction: null, createdAt: new Date().toISOString()
  },
  {
    id: 'listing-5', shopId: 'shop-1', title: 'Family Feast Pack (Serves 4-5)', category: 'meal', dealType: 'familyPack',
    originalPrice: 1200, discountPercent: 55, discountedPrice: 540, qtyKg: 2.5, unitsAvailable: 5,
    expiresAt: hrs(5), active: true, contents: 'Rice, 2 curries, roti, dessert', revealAfterPurchase: false,
    minPeopleForFamilyPack: 4, studentDeal: false, auction: null, createdAt: new Date().toISOString()
  },
  {
    id: 'listing-6', shopId: 'shop-4', title: 'Extra Home-style Tiffin', category: 'meal', dealType: 'tiffin',
    originalPrice: 150, discountPercent: 50, discountedPrice: 75, qtyKg: 0.5, unitsAvailable: 12,
    expiresAt: hrs(3), active: true, contents: null, revealAfterPurchase: false,
    minPeopleForFamilyPack: null, studentDeal: true, auction: null, createdAt: new Date().toISOString()
  },
  {
    id: 'listing-7', shopId: 'shop-5', title: 'Wedding Buffet Surplus', category: 'meal', dealType: 'eventLeftover',
    originalPrice: 5000, discountPercent: 70, discountedPrice: 1500, qtyKg: 15, unitsAvailable: 3,
    expiresAt: hrs(1), active: true, contents: 'Assorted North Indian buffet, serves 10', revealAfterPurchase: false,
    minPeopleForFamilyPack: null, studentDeal: false, auction: null, createdAt: new Date().toISOString()
  },
  {
    id: 'listing-8', shopId: 'shop-1', title: 'Everything-Must-Go Biryani Auction', category: 'meal', dealType: 'auction',
    originalPrice: 400, discountPercent: 50, discountedPrice: 200, qtyKg: 0.8, unitsAvailable: 20,
    expiresAt: hrs(1), active: true, contents: null, revealAfterPurchase: false,
    minPeopleForFamilyPack: null, studentDeal: false,
    auction: { basePrice: 200, floorPrice: 60, dropIntervalMin: 10, dropPercent: 15 },
    createdAt: new Date().toISOString()
  }
];

const db = {
  users, shops, listings,
  orders: [], clubs: [], donations: [], subscriptions: [], memberships: [], reviews: []
};

save(db);
console.log('Seed complete:');
console.log(`  ${users.length} users (login demo@resq.in / password123)`);
console.log(`  ${shops.length} shops`);
console.log(`  ${listings.length} listings across deal types: ${[...new Set(listings.map(l => l.dealType))].join(', ')}`);
